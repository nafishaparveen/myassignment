package com.example.three.SpringRestPincode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestPincodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
