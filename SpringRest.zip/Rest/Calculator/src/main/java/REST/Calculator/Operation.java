package REST.Calculator;

public interface Operation {

 long apply(long a, long b);

 boolean valid(char operator);

}