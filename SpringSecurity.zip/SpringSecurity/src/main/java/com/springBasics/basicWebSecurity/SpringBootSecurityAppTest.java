package com.springBasics.basicWebSecurity;

public class SpringBootSecurityAppTest {

}
